# voice_gender_recognition
Simple script in python to recognize gender using audio samples.

Implemented two methods:

- autocorrelation (89% correctly recognized)
- HPS - Harmonic Product Spectrum (96.7 correctly recognized)

Our algorithm was tested on 91 different audio samples.
As an output we return coverage matrix and the efficiency (correct/fail ratio)
